const MainRoutes = {
  path: '/main',
  
  redirect: '/main',
  component: () => import('@/layouts/dashboard/DashboardLayout.vue'),
  children: [
    {
      name: 'LandingPage',
      path: '/',
      component: () => import('@/views/dashboard/DefaultDashboard.vue')
    },
    {
      name: 'Dashboard',
      path: '/dashboard',
      component: () => import('@/views/dashboard/DefaultDashboard.vue')
    },
    {
      name: 'CoinFlip',
      path: '/coinflip',
      component: () => import('@/views/slot/CoinFlipView.vue')
    },
    {
      name: 'Colors',
      path: '/colors',
      component: () => import('@/views/colors/ColorPage.vue')
    },
    {
      name: 'MineField',
      path: '/minefield',
      component: () => import('@/views/slot/MineField.vue')
    },
    {
      name: 'Color',
      path: '/icon/ant',
      component: () => import('@/views/icons/AntDesignIcons.vue')
    },
    {
      name: 'other',
      path: '/sample-page',
      component: () => import('@/views/StarterPage.vue')
    },
    {
      name: 'tranzakcio',
      path: '/tranzakcio',
      component: () =>import('@/views/TranzakcioView.vue')
    }
  ]
};

export default MainRoutes;
