<template>
  <v-container class="coin-container">
    <v-row>
      <v-col>
        <div>
    <div :class="['coin', flipping ? 'flipping' : '', result]">
      <div class="side heads">H</div>
      <div class="side tails">T</div>
    </div>
  </div>
  
  <!-- Eredmény kiírása -->
  <h1 v-if="result" :class="['result-text', result]">
    {{ result === 'heads' ? 'Heads' : 'Tails' }}
  </h1>
      </v-col>
    </v-row>
    
  </v-container>
  
  <v-container width="300" class="bottom-container">
    <v-row>
      <v-col>
        <v-text-field 
        variant="solo"
          v-model="betInput" 
          type="number"
           min="1"
          
          suffix="Ft"
          placeholder="Enter your bet" 
          
        />
        
      

        <v-select
        variant="solo"
        v-model="sideInput"
        :items="[{title: 'Heads', value: 0},{title:'Tails', value:1}]" 
        placeholder="Choose Heads or Tails"
        density="comfortable"
/>

        
        <v-btn block :disabled="isFlipping || sideInput == null || betInput <= 0"
        variant="flat" color="primary" @click="flipCoin()">
        
          
          Feldobás
        </v-btn>
      </v-col>
    </v-row>
    
   </v-container>

</template>

<script setup lang="ts">
import type { title } from 'process';
import type { Value } from 'sass';
import { ref } from 'vue';

const betInput = ref(0);
const sideInput = ref<null | number>(null);
const isFlipping = ref(false);
const flipping = ref(false);
const result = ref('');
const showResult = ref(false);

const flipCoin = () => {
  if (flipping.value) return;
  isFlipping.value = true;
  flipping.value = true;
  result.value = '';
  showResult.value = false;

  setTimeout(() => {
    result.value = Math.random() < 0.5 ? 'heads' : 'tails';
    showResult.value = true;
  }, 5000);

  setTimeout(() => {
    flipping.value = false;
  }, 5000);

  // Emit the result immediately after the flip
  setTimeout(() => {
    if (showResult.value) {
      emit('result', result.value);
    }
  }, 1000);
  isFlipping.value = false;
};

// To emit events in `setup` with `script setup`, you can use defineEmits
const emit = defineEmits<{
  (e: 'result', result: string): void;
}>();
</script>


<style scoped>
.coin-container {
  margin-top: 20%;
  display: flex;
  justify-content: center;
  align-items: center;
  width: 100px;
  height: 100px;
  cursor: pointer;
}
.coin {
  width: 150px;
  height: 150px;
  position: relative;
  transform-style: preserve-3d;
  background-image: url(coin.png);
  background-size: cover;
  background-position: center;
  border-radius: 50%;
  transition: transform 1s;
}
.coin.flipping {
  animation: flip 5s cubic-bezier(0.3, 0.3, 0.3, 0.3);
}
.coin.heads {
  transform: rotateX(0deg);
}
.coin.tails {
  transform: rotateX(180deg);
}
.side {
  position: absolute;
  width: 100%;
  height: 100%;
  backface-visibility: hidden;
  display: flex;
  align-items: center;
  justify-content: center;
  font-size: 30px;
  color: #424242;
  font-weight: bold;
  border-radius: 50%;
}
.side.tails {
  transform: rotateX(180deg);
}

@keyframes flip {
  0% {
    transform: rotateX(0deg);
  }
  100% {
    transform: rotateX(720deg);
  }
}

/* Tüzes hatású animáció az eredmény szövegre */
.result-text {
  font-size: 3em;
  text-align: center;
  margin-top: 20px;
  font-family: 'Arial', sans-serif;
  font-weight: bold;
  color: #f1c40f;
  position: relative;
  animation: fireEffect 1s ease forwards; /* Tüzes animáció */
}

/* Lángoló effektus */
@keyframes fireEffect {
  0% {
    transform: scale(0);
    opacity: 0;
    text-shadow: 0 0 5px #e67e22, 0 0 10px #e67e22, 0 0 15px #e67e22;
  }
  50% {
    transform: scale(1.1);
    opacity: 1;
    text-shadow: 0 0 10px #e67e22, 0 0 20px #e67e22, 0 0 30px #e67e22;
  }
  100% {
    transform: scale(1);
    opacity: 1;
    text-shadow: 0 0 20px #f39c12, 0 0 30px #f39c12, 0 0 50px #f39c12, 0 0 60px #f39c12;
  }
}

/* Bouncing effect for the result text */
@keyframes bounce {
  0% {
    transform: translateY(0);
  }
  30% {
    transform: translateY(-10px);
  }
  50% {
    transform: translateY(5px);
  }
  70% {
    transform: translateY(-5px);
  }
  100% {
    transform: translateY(0);
  }
}

.bottom-container {
  width: 100%;
  max-width: 400px;
  padding: 20px;
  text-align: center;
  margin-bottom: 15vh;
  margin-top: 50px;
  display: flex;
  flex-direction: column;
  justify-content: center; /* Középre igazítja a tartalmat */
  align-items: center;
}


</style>
