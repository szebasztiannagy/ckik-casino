<template>
    <v-container class="d-flex justify-center align-center" style="height: 100vh; background-color: #222">
      <v-card class="pa-4" elevation="10" color="#333">
        <v-card-title class="text-center text-white">Minefield</v-card-title>
        <div class="minefield-grid">
          <div
            v-for="(cell, index) in grid" :key="index"
            @click="revealCell(index)"
            class="minefield-cell"
            :class="{ revealed: cell.revealed, bomb: cell.isBomb && cell.revealed }"
          >
            <span v-if="cell.revealed">{{ cell.isBomb ? '💣' : '' }}</span>
          </div>
        </div>
      </v-card>
    </v-container>
  </template>
  
  <script>
  export default {
    data() {
      return {
        bombIndex: Math.floor(Math.random() * 25),
        grid: Array.from({ length: 25 }, (_, index) => ({
          isBomb: false,
          revealed: false,
        })),
        gameOver: false,
      };
    },
    created() {
      this.grid[this.bombIndex].isBomb = true;
    },
    methods: {
      revealCell(index) {
        if (this.gameOver || this.grid[index].revealed) return;
        
        this.grid[index].revealed = true;
        this.grid = [...this.grid]; // Ensure reactivity in Vue 3
        
        if (this.grid[index].isBomb) {
          this.gameOver = true;
        }
      },
    },
  };
  </script>
  
  <style>
  .minefield-grid {
    display: grid;
    grid-template-columns: repeat(5, 1fr);
    gap: 5px;
    padding: 10px;
  }
  .minefield-cell {
    width: 50px;
    height: 50px;
    font-size: 20px;
    border-radius: 8px;
    background-color: green;
    display: flex;
    align-items: center;
    justify-content: center;
    cursor: pointer;
    transition: transform 0.4s, background-color 0.4s;
  }
  .minefield-cell.revealed {
    transform: rotateY(180deg);
    background-color: grey;
  }
  .minefield-cell.bomb {
    background-color: red;
  }
  </style>