<script setup lang="ts">
import { ref, computed, onMounted, watch, inject } from 'vue';
import { Roulette } from 'vue3-roulette';
import axios from 'axios';

const wheel = ref(null);
const betInput = ref<number | string>(100); 
// Alapértelmezett érték 100
const numberInput = ref<number | string>(0); // Alapértelmezett érték 0
const isSpinning = ref(false);
const isStopped = ref(false);
const spunNumber = ref<null | number | string>(null);
const resultMessage = ref('');
const showResult = ref(false);
const snackbarMessage = ref('');
const showSnackbar = ref(false);
// Injektáljuk a balance és updateBalance függvényt a NotificationDD komponensből
const balance = inject('balance', ref(100000000));
const updateBalance = inject('updateBalance', (newBalance) => {
  console.log('Default updateBalance fallback called with:', newBalance);
});

// Debug: Kiírjuk a konzolra az egyenleget
console.log('Injected balance:', balance.value);

const items = [
  { id: 1, name: "0", htmlContent: "0", textColor: "white", background: "#68BB45" },
  { id: 2, name: "32", htmlContent: "32", textColor: "white", background: "#EE2D2E" },
  { id: 3, name: "15", htmlContent: "15", textColor: "white", background: "#000" },
  { id: 4, name: "19", htmlContent: "19", textColor: "white", background: "#EE2D2E" },
  { id: 5, name: "4", htmlContent: "4", textColor: "white", background: "#000" },
  { id: 6, name: "21", htmlContent: "21", textColor: "white", background: "#EE2D2E" },
  { id: 7, name: "2", htmlContent: "2", textColor: "white", background: "#000" },
  { id: 8, name: "25", htmlContent: "25", textColor: "white", background: "#EE2D2E" },
  { id: 9, name: "17", htmlContent: "17", textColor: "white", background: "#000" },
  { id: 10, name: "34", htmlContent: "34", textColor: "white", background: "#EE2D2E" },
  { id: 11, name: "6", htmlContent: "6", textColor: "white", background: "#000" },
  { id: 12, name: "27", htmlContent: "27", textColor: "white", background: "#EE2D2E" },
  { id: 13, name: "13", htmlContent: "13", textColor: "white", background: "#000" },
  { id: 14, name: "36", htmlContent: "36", textColor: "white", background: "#EE2D2E" },
  { id: 15, name: "11", htmlContent: "11", textColor: "white", background: "#000" },
  { id: 16, name: "30", htmlContent: "30", textColor: "white", background: "#EE2D2E" },
  { id: 17, name: "8", htmlContent: "8", textColor: "white", background: "#000" },
  { id: 18, name: "23", htmlContent: "23", textColor: "white", background: "#EE2D2E" },
  { id: 19, name: "10", htmlContent: "10", textColor: "white", background: "#000" },
  { id: 20, name: "5", htmlContent: "5", textColor: "white", background: "#EE2D2E" },
  { id: 21, name: "24", htmlContent: "24", textColor: "white", background: "#000" },
  { id: 22, name: "16", htmlContent: "16", textColor: "white", background: "#EE2D2E" },
  { id: 23, name: "33", htmlContent: "33", textColor: "white", background: "#000" },
  { id: 24, name: "1", htmlContent: "1", textColor: "white", background: "#EE2D2E" },
  { id: 25, name: "20", htmlContent: "20", textColor: "white", background: "#000" },
  { id: 26, name: "14", htmlContent: "14", textColor: "white", background: "#EE2D2E" },
  { id: 27, name: "31", htmlContent: "31", textColor: "white", background: "#000" },
  { id: 28, name: "9", htmlContent: "9", textColor: "white", background: "#EE2D2E" },
  { id: 29, name: "22", htmlContent: "22", textColor: "white", background: "#000" },
  { id: 30, name: "18", htmlContent: "18", textColor: "white", background: "#EE2D2E" },
  { id: 31, name: "29", htmlContent: "29", textColor: "white", background: "#000" },
  { id: 32, name: "7", htmlContent: "7", textColor: "white", background: "#EE2D2E" },
  { id: 33, name: "28", htmlContent: "28", textColor: "white", background: "#000" },
  { id: 34, name: "12", htmlContent: "12", textColor: "white", background: "#EE2D2E" },
  { id: 35, name: "35", htmlContent: "35", textColor: "white", background: "#000" },
  { id: 36, name: "3", htmlContent: "3", textColor: "white", background: "#EE2D2E" },
  { id: 37, name: "26", htmlContent: "26", textColor: "white", background: "#000" }
];

const wheelSize = computed(() => {
  const width = window.innerWidth;
  if (width < 480) return 100;  // Small screen size
  if (width < 768) return 200;  // Medium screen size
  return 350; // Large screen size
});

const baseSize = computed(() => {
  return wheelSize.value * 0.8;  // Base size is 80% of the wheel size
});

// Számított tulajdonság a gomb engedélyezéséhez
// In DefaultDashboard.vue, update the isButtonDisabled computed property


function showError(message: string) {
  snackbarMessage.value = message;
  showSnackbar.value = true;
}

const isButtonDisabled = computed(() => {
  // Convert values to numbers to ensure proper comparison
  const betAmount = Number(betInput.value);
  const number = Number(numberInput.value);
  
  // Access the balance value directly
  const currentBalance = Number(localStorage.getItem('balance'));
  
  
  // First check if bet amount is greater than balance
  if (betAmount > currentBalance) {
    showError('A tét összege nem lehet nagyobb, mint az egyenleg!');
    return true;
  }
  
  // Then check other conditions
  return isSpinning.value || 
         numberInput.value === null || 
         numberInput.value === '' || 
         betAmount <= 0 || 
         number < 0 || 
         number > 36;
});



// Játék eredményének mentése
// Replace the saveGameResult function in DefaultDashboard.vue with this:

const saveGameResult = async (isWin: boolean) => {
  try {
    const betAmount = Number(betInput.value);
    const pickedNumber = Number(numberInput.value);
    const resultNumber = Number(spunNumber.value);
    
    // Call the API to process the game
    const token = localStorage.getItem('token');
    if (!token) {
      alert('Nincs bejelentkezve! Kérjük jelentkezzen be újra.');
      return;
    }
    
    const response = await axios.post('http://localhost:5000/api/games/play', {
      type: 'roulette',
      bet: betAmount,
      picked: pickedNumber,
      result: resultNumber
    }, {
      headers: {
        Authorization: `Bearer ${token}`
      }
    });
    
    // Update the balance with the value returned from the server
    if (response.data && response.data.newBalance !== undefined) {
      updateBalance(response.data.newBalance);
    }
    
    // Set result message
    if (isWin) {
      resultMessage.value = `Gratulálunk! Nyertél ${betAmount * 36} Ft-ot!`;
    } else {
      resultMessage.value = `Sajnos vesztettél ${betAmount} Ft-ot.`;
    }
    showResult.value = true;
    
    // Hide result message after 3 seconds
    setTimeout(() => {
      showResult.value = false;
    }, 3000);
    
  } catch (error) {
    console.error('Hiba a játék eredményének mentésekor:', error);
    if (error.response && error.response.data && error.response.data.message) {
      alert(`Hiba: ${error.response.data.message}`);
    } else {
      alert('Hiba történt a játék során.');
    }
  }
};


function launchWheel() {
  if (isSpinning.value) return;
  
  // Ellenőrizzük, hogy van-e elegendő egyenleg
  const betAmount = Number(betInput.value);
  if (betAmount > balance.value) {
    alert('Nincs elegendő egyenleged a tét megtételéhez!');
    return;
  }
  
  isSpinning.value = true;
  wheel.value.launchWheel();
}


function resetWheel() {
  wheel.value?.reset();
}

async function onWheelEnd(value: any) {
  spunNumber.value = value.name;
  console.log(`Kipörgött szám: ${value.name}`);
  
  // Ellenőrizzük, hogy nyert-e a játékos
  const isWin = Number(value.name) === Number(numberInput.value);
  
  // Játék eredményének mentése
  await saveGameResult(isWin);
  
  resetWheel();
  isSpinning.value = false;
  numberInput.value = 0; // Alapértelmezett érték 0
  betInput.value = 100; // Alapértelmezett érték 100
}

onMounted(() => {
  // Alapértelmezett értékek beállítása
  betInput.value = 100;
  numberInput.value = 0;
  
  // Ablak átméretezés figyelése
  window.addEventListener('resize', () => {
    // Computed property újraszámolása
  });
});
</script>

<template>
  <div>
    <v-snackbar v-model="showSnackbar" :timeout="3000" color="error">
      {{ snackbarMessage }}
    </v-snackbar>
    <Roulette 
      ref="wheel" 
      :items="items" 
      :display-shadow="false"
      :display-indicator="false"
      :centered-indicator="true" 
      :counter-clockwise="true"
      :size="wheelSize"
      :duration="4" 
      :result-variation="70"
      easing="ease"   
      indicator-position="top"
      :base-display="true"
      :base-display-indicator="false"
      :base-size="baseSize"
      base-background="#EEAA33" 
      @wheel-end="onWheelEnd"
      class="d-flex"
    >
      <template #baseContent>
        <img src="../../../roulette.png" :height="baseSize + 'px'" />
      </template>
    </Roulette>

    <v-container width="300">
      <v-row>
        <v-col>
          <h1 v-if="spunNumber !== null">Kipörgetett szám: </h1>
          <h1>{{ spunNumber }}</h1>
          
          <!-- Eredmény üzenet -->
          <v-alert
              v-if="Number(betInput) > Number(balance)"
              type="warning"
              class="mt-2 mb-2"
              density="compact"
            >
              A tét meghaladja az egyenlegedet!
          </v-alert>

          
          <v-text-field 
            variant="solo"
            v-model="betInput" 
            
            type="number"
            min="1"
            suffix="Ft"
            placeholder="Add meg a tétet" 
          />
          <v-alert
            v-if="Number(betInput) > balance"
            type="warning"
            class="mt-2 mb-2"
            density="compact"
          >
            A tét meghaladja az egyenlegedet!
          </v-alert>


          
          <v-text-field
            variant="solo"
            v-model="numberInput" 
            type="number" 
            max="36"
            min="0"
            placeholder="Add meg a számot (0-36)" 
          />
          
          <v-btn 
            block 
            :disabled="isButtonDisabled"
            variant="flat" 
            color="primary" 
            @click="launchWheel()"
          >
            Pörgetés
          </v-btn>
          
          <!-- Debug információk -->
          <div v-if="false" class="mt-4">
            <p>betInput: {{ betInput }}</p>
            <p>numberInput: {{ numberInput }}</p>
            <p>balance: {{ balance }}</p>
            <p>isButtonDisabled: {{ isButtonDisabled }}</p>
          </div>
        </v-col>
      </v-row>
    </v-container>
  </div>
</template>

<style scoped>
/* Base Styles */
* {
  box-sizing: border-box;
}

input {
  padding: 10px;
  font-size: 16px;
  border: 1px solid #ccc;
  border-radius: 8px;
  outline: none;
  background-color: white;
}

@media (max-width: 500px) {
  .roulette-container {
    max-width: 60%;
    margin: 0 auto;
  }

  .bet-container {
    align-items: center;
  }

  .input-bet {
    flex-direction: column;
    align-items: center;
  }

  .bet-input {
    width: 100%;
    margin-bottom: 10px;
  }

  .reset-button, .place-bet-button {
    font-size: 14px;
    padding: 10px 20px;
  }
}

@media (max-width: 300px) {
  .roulette-container {
    max-width: 60%;
    margin: 0 auto;
  }

  .bet-input {
    width: 100%;
    padding: 12px;
    font-size: 14px;
  }

  .place-bet-button {
    padding: 10px 18px;
  }
}

h1 {
  color: white;
  font-family: Cambria, Cochin, Georgia, Times, 'Times New Roman', serif;
  text-align: center;
}
</style>
