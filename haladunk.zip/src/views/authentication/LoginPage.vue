// src/views/authentication/LoginPage.vue
<template>
  <v-container class="fill-height d-flex align-center justify-center">
    <v-card class="pa-6" width="400">
      <v-card-title class="text-h5 text-center">Bejelentkezés</v-card-title>
      <v-card-text>
        <v-form @submit.prevent="login">
          <v-text-field 
            label="Email"
            v-model="email"
            type="email"
            required
            outlined
          ></v-text-field>

          <v-text-field 
            label="Jelszó"
            v-model="password"
            type="password"
            required
            outlined
          ></v-text-field>

          <v-alert v-if="errorMessage" type="error" dense>
            {{ errorMessage }}
          </v-alert>

          <v-btn type="submit" color="primary" block class="mt-4">Bejelentkezés</v-btn>
          <v-btn type="submit" append-icon="$edit" block class="mt-4" color="primary" @click="$router.push('/register')">Regisztráció</v-btn>
        </v-form>
      </v-card-text>
    </v-card>
  </v-container>
</template>

<script lang="ts" setup>
import { ref } from 'vue';
import { useRouter } from 'vue-router';
import axios from 'axios';

const email = ref('');
const password = ref('');
const errorMessage = ref('');
const router = useRouter();

const login = async () => {
  try {
    const response = await axios.post('http://localhost:5000/api/auth/login', {
      email: email.value,
      password: password.value,
    });

    const { token, userId, balance } = response.data;

    localStorage.setItem('token', token);
    localStorage.setItem('userId', userId);
    localStorage.setItem('balance', balance);
    console.log(token);
    router.push('/dashboard');
  } catch (error) {
    errorMessage.value = 'Hibás email vagy jelszó!';
  }
};
</script>


<style scoped>
.v-application{
  background-color: "black";
}
.--v-theme{
  background-color: black;
}
</style>
