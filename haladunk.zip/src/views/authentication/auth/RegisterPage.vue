// src/views/authentication/RegisterPage.vue
<template>
  <v-container class="fill-height d-flex align-center justify-center">
    <v-card class="pa-6" width="400">
      <v-card-title class="text-h5 text-center">Regisztráció</v-card-title>
      <v-card-text>
        <v-form @submit.prevent="register">
          <v-text-field 
            label="Felhasználónév"
            v-model="username"
            type="text"
            required
            outlined
          ></v-text-field>
          
          <v-text-field 
            label="Email"
            v-model="email"
            type="email"
            required
            outlined
          ></v-text-field>

          <v-text-field 
            label="Jelszó"
            v-model="password"
            type="password"
            required
            outlined
          ></v-text-field>

          <v-text-field 
            label="Jelszó megerősítése"
            v-model="confirmPassword"
            type="password"
            required
            outlined
          ></v-text-field>

          <v-alert v-if="errorMessage" type="error" dense>
            {{ errorMessage }}
          </v-alert>

          <v-btn type="submit" color="primary" block class="mt-4">Regisztráció</v-btn>
          <v-btn @click="$router.push('/login')" color="secondary" block class="mt-2">Van már fiókom</v-btn>
        </v-form>
      </v-card-text>
    </v-card>
  </v-container>
</template>

<script>
import axios from "axios";

export default {
  data() {
    return {
      username: "",
      email: "",
      password: "",
      confirmPassword: "",
      errorMessage: "",
    };
  },
  methods: {
    async register() {
      if (this.password !== this.confirmPassword) {
        this.errorMessage = "A jelszavak nem egyeznek!";
        return;
      }
      try {
        await axios.post("http://localhost:5000/api/auth/register", {
          username: this.username,
          email: this.email,
          password: this.password,
        });

        this.$router.push("/login");
      } catch (error) {
        this.errorMessage = "A regisztráció sikertelen!";
      }
    },
  },
};
</script>

<style scoped>
.v-application{
  background-color: "black";
}
.--v-theme{
  background-color: black;
}
</style>
