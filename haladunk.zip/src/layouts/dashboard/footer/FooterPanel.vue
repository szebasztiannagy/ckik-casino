<script setup lang="ts">
</script>

<template>
  <div class="kaszi-no">
    
    <a href="mailto:kaszinoservice@gmail.com">Segítségre van szükséged?</a>
  </div>
</template>

<style scoped>
.kaszi-no {
  color: rgb(255, 255, 255); /* Válaszd ki a kívánt színt */
}
a{
  color: rgb(255, 255, 255);
  text-decoration: none;
}
</style>
