<template>
  <div class="logo">
    <RouterLink to="/dashboard" aria-label="logo">
      <img src="../../../../Névtelen.png">
    </RouterLink>
  </div>
</template>
<script setup lang="ts">
</script>
