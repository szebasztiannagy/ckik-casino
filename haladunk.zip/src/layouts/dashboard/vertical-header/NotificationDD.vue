<script setup lang="ts">
import { ref, onMounted, provide } from 'vue';
import axios from 'axios';

const balance = ref(1000); // Alapértelmezett érték

// Eseménykezelő az egyenleg frissítéséhez
const updateBalance = (newBalance) => {
  balance.value = newBalance;
  localStorage.setItem('balance', newBalance.toString());
};

// Provide a balance és az updateBalance függvényt, hogy más komponensek is használhassák
provide('balance', balance);
provide('updateBalance', updateBalance);

onMounted(async () => {
  await fetchUserBalance();
});

// Replace the fetchUserBalance function in NotificationDD.vue with this:

const fetchUserBalance = async () => {
  try {
    const token = localStorage.getItem('token');
    if (token) {
      const response = await axios.get('http://localhost:5000/api/users/profile', {
        headers: {
          Authorization: `Bearer ${token}`
        }
      });
      
      if (response.data && response.data.balance !== undefined) {
        balance.value = response.data.balance;
        localStorage.setItem('balance', response.data.balance.toString());
      } else {
        // Fallback to localStorage if API doesn't return balance
        const storedBalance = localStorage.getItem('balance');
        if (storedBalance) {
          balance.value = parseFloat(storedBalance);
        }
      }
    } else {
      // No token, use localStorage
      const storedBalance = localStorage.getItem('balance');
      if (storedBalance) {
        balance.value = parseFloat(storedBalance);
      }
    }
  } catch (error) {
    console.error('Hiba az egyenleg lekérésekor:', error);
    // Fallback to localStorage on error
    const storedBalance = localStorage.getItem('balance');
    if (storedBalance) {
      balance.value = parseFloat(storedBalance);
    } else {
      // Default value if nothing else works
      balance.value = 1000;
      localStorage.setItem('balance', '1000');
    }
  }
};

</script>

<template>
  <v-btn
    icon
    class="text-secondary"
    color="darkText"
    rounded="sm"
    variant="text"
    size="small"
  >
    <div class="balance-display">{{ balance }} Ft                 </div>
  </v-btn>
</template>

<style scoped lang="scss">
.v-tooltip {
  > .v-overlay__content.custom-tooltip {
    padding: 2px 6px;
  }
}

.balance-display {
  font-weight: bold;
  padding: 0 8px;
  white-space: nowrap;
  color: white;
  margin-right: 5px;
}
</style>
