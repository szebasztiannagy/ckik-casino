// api/repositories/historyRepository.js
const History = require('../models/History');

class HistoryRepository {
  async create(historyData) {
    return await History.create(historyData);
  }

  async findByUserId(userId, limit = 10, offset = 0) {
    return await History.findByUserId(userId, limit, offset);
  }

  async getStats(userId) {
    return await History.getStats(userId);
  }
}

module.exports = new HistoryRepository();
