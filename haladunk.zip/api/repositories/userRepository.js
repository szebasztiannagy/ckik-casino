// api/repositories/userRepository.js
const User = require('../models/User');

class UserRepository {
  async findById(id) {
    try {
      return await User.findById(id);
    } catch (error) {
      console.error('Error in findById:', error);
      throw error;
    }
  }

  async findByEmail(email) {
    try {
      return await User.findByEmail(email);
    } catch (error) {
      console.error('Error in findByEmail:', error);
      throw error;
    }
  }

  async create(userData) {
    try {
      return await User.create(userData);
    } catch (error) {
      console.error('Error in create:', error);
      throw error;
    }
  }

  async updateBalance(userId, amount) {
    try {
      return await User.updateBalance(userId, amount);
    } catch (error) {
      console.error('Error in updateBalance:', error);
      throw error;
    }
  }

  async getBalance(userId) {
    try {
      return await User.getBalance(userId);
    } catch (error) {
      console.error('Error in getBalance:', error);
      throw error;
    }
  }
}

module.exports = new UserRepository();
