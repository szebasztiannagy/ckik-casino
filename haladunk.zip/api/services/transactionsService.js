// api/services/transactionsService.js
const userRepository = require('../repositories/userRepository');
const historyRepository = require('../repositories/historyRepository');

class TransactionsService {
  async deposit(userId, amount) {
    if (amount <= 0) {
      throw new Error('Amount must be positive');
    }
    
    await userRepository.updateBalance(userId, amount);
    
    await historyRepository.create({
      type: 'deposit',
      result: 'success',
      bet: null,
      picked: null,
      amount,
      user_id: userId
    });
    
    const newBalance = await userRepository.getBalance(userId);
    
    return {
      amount,
      newBalance
    };
  }
  
  async withdraw(userId, amount) {
    if (amount <= 0) {
      throw new Error('Amount must be positive');
    }
    
    const balance = await userRepository.getBalance(userId);
    if (balance < amount) {
      throw new Error('Insufficient balance');
    }
    
    await userRepository.updateBalance(userId, -amount);
    
    await historyRepository.create({
      type: 'withdraw',
      result: 'success',
      bet: null,
      picked: null,
      amount,
      user_id: userId
    });
    
    const newBalance = await userRepository.getBalance(userId);
    
    return {
      amount,
      newBalance
    };
  }
}

module.exports = new TransactionsService();
