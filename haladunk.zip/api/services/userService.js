// api/services/userService.js
const userRepository = require('../repositories/userRepository');
const historyRepository = require('../repositories/historyRepository');

class UserService {
  async getUserProfile(userId) {
    try {
      const user = await userRepository.findById(userId);
      if (!user) {
        throw new Error('User not found');
      }
      
      const balance = await userRepository.getBalance(userId);
      return {
        ...user,
        balance
      };
    } catch (error) {
      console.error('Error in getUserProfile:', error);
      throw error;
    }
  }
  
  async getUserHistory(userId, limit = 10, offset = 0) {
    try {
      return await historyRepository.findByUserId(userId, limit, offset);
    } catch (error) {
      console.error('Error in getUserHistory:', error);
      throw error;
    }
  }
  
  async getUserStats(userId) {
    try {
      return await historyRepository.getStats(userId);
    } catch (error) {
      console.error('Error in getUserStats:', error);
      throw error;
    }
  }
}

module.exports = new UserService();
