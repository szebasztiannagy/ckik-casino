// api/services/gameService.js
const userRepository = require('../repositories/userRepository');
const historyRepository = require('../repositories/historyRepository');

class GameService {
  async playGame(userId, gameData) {
    const { type, bet, amount, picked, result: resultNumber } = gameData;
    
    // Check if user has enough balance
    const balance = await userRepository.getBalance(userId);

    if (balance < bet) {
      throw new Error('Insufficient balance');
    }

    
    let result, isWin, balanceChange;
    
    if (type === 'roulette') {
      // Roulette game logic
      // Check if user won
      isWin = parseInt(picked) === parseInt(resultNumber);
      
      // First deduct the bet from user's balance
      await userRepository.updateBalance(userId, -bet);
      
      if (isWin) {
        // If won, user gets 36 times the bet (plus the original bet)
        const winAmount = bet * 36;
        balanceChange = winAmount;
        result = 'win';
        
        // Add winnings to balance
        await userRepository.updateBalance(userId, winAmount + bet);
      } else {
        // If lost, bet is already deducted
        balanceChange = -bet;
        result = 'loss';
      }
      
      // Save game history
      await historyRepository.create({
        type,
        result,
        bet,
        picked,
        amount: Math.abs(balanceChange), // Amount is always positive, result indicates win or loss
        user_id: userId
      });
    } else {
      // Logic for other games (if any)
      // ...
      
      // Default random result
      const isRandomWin = Math.random() > 0.5;
      result = isRandomWin ? 'win' : 'loss';
      
      // First deduct the bet
      await userRepository.updateBalance(userId, -bet);
      
      if (isRandomWin) {
        // If won, add winnings
        const winAmount = bet * 2; // Example: double the bet
        balanceChange = winAmount;
        
        // Add winnings to balance
        await userRepository.updateBalance(userId, winAmount + bet);
      } else {
        // If lost, bet is already deducted
        balanceChange = -bet;
      }
      
      // Save game history
      await historyRepository.create({
        type,
        result,
        bet,
        picked,
        amount: Math.abs(balanceChange),
        user_id: userId
      });
    }
    
    // Get updated balance
    const newBalance = await userRepository.getBalance(userId);
    
    return {
      result,
      balanceChange,
      newBalance
    };
  }
}


module.exports = new GameService();
