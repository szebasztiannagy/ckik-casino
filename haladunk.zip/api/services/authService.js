// api/services/authService.js
const bcrypt = require('bcrypt');
const jwt = require('jsonwebtoken');
const userRepository = require('../repositories/userRepository');

class AuthService {

  async register(userData) {
    const { username, email, password } = userData;
    const normalizedEmail = email.toLowerCase().trim();
    
    // Check if user already exists
    const existingUser = await userRepository.findByEmail(normalizedEmail);
    if (existingUser) {
      throw new Error('User with this email already exists');
    }

    // Hash password
    const password_hash = await bcrypt.hash(password, 10);
    console.log('Password Hash:', password_hash);

    // Create user
    const userId = await userRepository.create({
      username,
      email: normalizedEmail,
      password_hash
    });

    return { userId };
  }

  async login(email, password) {
    const normalizedEmail = email.toLowerCase().trim();
    
    // Find user
    const user = await userRepository.findByEmail(normalizedEmail);
    console.log('User Found:', user);
    if (!user) {
      throw new Error('Invalid credentials');
    }

    // Verify password
    const isMatch = await bcrypt.compare(password, user.password_hash);

    console.log('Password Match:', isMatch);
    if (!isMatch) {
      throw new Error('Invalid credentials');
    }

    // Generate token
    const token = jwt.sign(
      { id: user.id },
      process.env.JWT_SECRET || 'your_jwt_secret',
      { expiresIn: '1d' }
    );

    const balance = await userRepository.getBalance(user.id);

    return {
      token,
      userId: user.id,
      balance
    };
  }
}

module.exports = new AuthService();
