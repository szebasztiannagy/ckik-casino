// api/models/History.js
const db = require('../db');

class History {
  static async create(historyData) {
    const { type, result, bet, picked, amount, user_id } = historyData;
    const [queryResult] = await db.query(
      'INSERT INTO history (type, result, bet, picked, amount, user_id, created_at) VALUES (?, ?, ?, ?, ?, ?, NOW())',
      [type, result, bet, picked, amount, user_id]
    );
    return queryResult.insertId;
  }

  static async findByUserId(userId, limit = 10, offset = 0) {
    const [rows] = await db.query(
      'SELECT * FROM history WHERE user_id = ? ORDER BY created_at DESC LIMIT ? OFFSET ?',
      [userId, limit, offset]
    );
    return rows;
  }

  static async getStats(userId) {
    const [rows] = await db.query(
      'SELECT type, COUNT(*) as count, SUM(CASE WHEN result = "win" THEN amount ELSE 0 END) as winnings, ' +
      'SUM(CASE WHEN result = "loss" THEN amount ELSE 0 END) as losses ' +
      'FROM history WHERE user_id = ? GROUP BY type',
      [userId]
    );
    return rows;
  }
}

module.exports = History;
