// api/models/User.js
const db = require('../db');

class User {
  static async findById(id) {
    try {
      const [rows] = await db.query('SELECT id, username, email, created_at FROM users WHERE id = ?', [id]);
      return rows[0];
    } catch (error) {
      console.error('Error in User.findById:', error);
      throw error;
    }
  }

  static async findByEmail(email) {
    try {
      const [rows] = await db.query('SELECT * FROM users WHERE email = ?', [email]);
      return rows[0];
    } catch (error) {
      console.error('Error in User.findByEmail:', error);
      throw error;
    }
  }

  static async create(userData) {
    try {
      const { username, email, password_hash } = userData;
      const [result] = await db.query(
        'INSERT INTO users (username, email, password_hash, created_at, balance) VALUES (?, ?, ?, NOW(), 1000)',
        [username, email, password_hash]
      );
      return result.insertId;
    } catch (error) {
      console.error('Error in User.create:', error);
      throw error;
    }
  }

  static async updateBalance(userId, amount) {
    try {
      const [result] = await db.query(
        'UPDATE users SET balance = balance + ? WHERE id = ?',
        [amount, userId]
      );
      return result.affectedRows > 0;
    } catch (error) {
      console.error('Error in User.updateBalance:', error);
      throw error;
    }
  }

  static async getBalance(userId) {
    try {
      const [result] = await db.query('SELECT balance FROM users WHERE id = ?', [userId]);
      if (result.length === 0) {
        return 0;
      }
      return result[0].balance || 0;
    } catch (error) {
      console.error('Error in User.getBalance:', error);
      throw error;
    }
  }
}

module.exports = User;
