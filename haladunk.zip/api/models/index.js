// api/models/index.js
const User = require('./User');
const History = require('./History');

module.exports = {
  User,
  History
};
