// api/routes/transactionRoutes.js
const express = require('express');
const router = express.Router();
const transactionsController = require('../controllers/transactionsController');
const authMiddleware = require('../middlewares/authMiddleware');

router.use(authMiddleware);

router.post('/deposit', transactionsController.deposit);
router.post('/withdraw', transactionsController.withdraw);

module.exports = router;
