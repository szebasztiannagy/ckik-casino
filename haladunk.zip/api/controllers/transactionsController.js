// api/controllers/transactionsController.js
const transactionsService = require('../services/transactionsService');

class TransactionsController {
  async deposit(req, res, next) {
    try {
      const userId = req.user.id;
      const { amount } = req.body;
      
      if (!amount || isNaN(amount) || amount <= 0) {
        return res.status(400).json({ message: 'Valid amount is required' });
      }
      
      const result = await transactionsService.deposit(userId, parseFloat(amount));
      
      res.status(200).json(result);
    } catch (error) {
      next(error);
    }
  }
  
  async withdraw(req, res, next) {
    try {
      const userId = req.user.id;
      const { amount } = req.body;
      
      if (!amount || isNaN(amount) || amount <= 0) {
        return res.status(400).json({ message: 'Valid amount is required' });
      }
      
      const result = await transactionsService.withdraw(userId, parseFloat(amount));
      
      res.status(200).json(result);
    } catch (error) {
      next(error);
    }
  }
}

module.exports = new TransactionsController();
