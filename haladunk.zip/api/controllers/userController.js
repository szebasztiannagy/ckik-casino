// api/controllers/userController.js
const userService = require('../services/userService');

class UserController {
  async getProfile(req, res, next) {
    try {
      const userId = req.user.id;
      const profile = await userService.getUserProfile(userId);
      
      res.status(200).json(profile);
    } catch (error) {
      next(error);
    }
  }
  
  async getHistory(req, res, next) {
    try {
      const userId = req.user.id;
      const { limit = 10, offset = 0 } = req.query;
      
      const history = await userService.getUserHistory(userId, parseInt(limit), parseInt(offset));
      
      res.status(200).json(history);
    } catch (error) {
      next(error);
    }
  }
  
  async getStats(req, res, next) {
    try {
      const userId = req.user.id;
      const stats = await userService.getUserStats(userId);
      
      res.status(200).json(stats);
    } catch (error) {
      next(error);
    }
  }
}

module.exports = new UserController();
