// api/controllers/gameController.js
const gameService = require('../services/gameService');

class GameController {
  async playGame(req, res, next) {
    try {
      const userId = req.user.id;
      const { type, bet, amount, picked, result } = req.body;
      
      if (!type || !bet) {
        return res.status(400).json({ message: 'Type and bet are required' });
      }
      
      const gameResult = await gameService.playGame(userId, { type, bet, amount, picked, result });
      
      res.status(200).json(gameResult);
    } catch (error) {
      next(error);
    }
  }
}

module.exports = new GameController();
