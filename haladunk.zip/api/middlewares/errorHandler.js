// api/middlewares/errorHandler.js
module.exports = (err, req, res, next) => {
    console.error(err.stack);
    
    if (err.message === 'User with this email already exists') {
      return res.status(400).json({ message: err.message });
    }
    
    if (err.message === 'Invalid credentials') {
      return res.status(401).json({ message: 'Invalid email or password' });
    }
    
    if (err.message === 'User not found') {
      return res.status(404).json({ message: err.message });
    }
    
    if (err.message === 'Insufficient balance') {
      return res.status(400).json({ message: err.message });
    }
    
    res.status(500).json({ message: 'Server error' });
  };
  